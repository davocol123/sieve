import argparse
import time

from sequential import sequential_sieve
from parallel import parallel_sieve


def main():
    parser = argparse.ArgumentParser(
        description="Parallel Sieve of Eratosthenes"
    )

    parser.add_argument(
        "--limit",
        type=int,
        required=True,
        help="Maximum number to search"
    )

    parser.add_argument(
        "--workers",
        type=int,
        default=4,
        help="Number of worker processes"
    )

    parser.add_argument(
        "--mode",
        choices=["parallel", "sequential"],
        default="parallel",
        help="Execution mode"
    )

    args = parser.parse_args()

    start = time.perf_counter()

    if args.mode == "parallel":
        primes = parallel_sieve(
            args.limit,
            args.workers
        )
    else:
        primes = sequential_sieve(
            args.limit
        )

    elapsed = time.perf_counter() - start

    print("\n===== RESULTS =====")
    print(f"Limit: {args.limit:,}")
    print(f"Mode: {args.mode}")
    print(f"Workers: {args.workers}")
    print(f"Primes Found: {len(primes):,}")
    print(f"Execution Time: {elapsed:.4f} seconds")


if __name__ == "__main__":
    main()