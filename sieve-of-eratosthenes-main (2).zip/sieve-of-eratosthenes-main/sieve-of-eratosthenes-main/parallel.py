import math
from concurrent.futures import ProcessPoolExecutor


def simple_sieve(limit):
    sieve = [True] * (limit + 1)
    sieve[0] = sieve[1] = False

    for i in range(2, int(math.sqrt(limit)) + 1):
        if sieve[i]:
            for j in range(i * i, limit + 1, i):
                sieve[j] = False

    return [i for i in range(limit + 1) if sieve[i]]


def sieve_segment(start, end, base_primes):
    size = end - start

    segment = [True] * size

    for prime in base_primes:
        first_multiple = max(
            prime * prime,
            ((start + prime - 1) // prime) * prime
        )

        for multiple in range(first_multiple, end, prime):
            segment[multiple - start] = False

    result = []

    for i in range(size):
        number = start + i

        if number > 1 and segment[i]:
            result.append(number)

    return result


def parallel_sieve(limit, workers):
    if limit < 2:
        return []

    sqrt_limit = int(math.sqrt(limit))

    base_primes = simple_sieve(sqrt_limit)

    chunk_size = max(
        1,
        (limit - sqrt_limit) // workers
    )

    results = []

    with ProcessPoolExecutor(max_workers=workers) as executor:
        futures = []

        start = sqrt_limit + 1

        while start <= limit:
            end = min(start + chunk_size, limit + 1)

            futures.append(
                executor.submit(
                    sieve_segment,
                    start,
                    end,
                    base_primes
                )
            )

            start = end

        for future in futures:
            results.extend(future.result())

    return sorted(base_primes + results)